import math
import numpy as np
import matplotlib.pyplot as plt


def taylor_seris(x, n):
    cos_approx = 0
    # your code here
    return cos_approx


def plot_taylor_seris_one_to_five(angles):
    for i in range(1,6):
        t_cos = [taylor_seris(angle,i) for angle in angles]
        ax.plot(angles,t_cos)

    ax.set_ylim([-7,4])

    legend_lst = ['cos() function']
    for i in range(1,6):
        legend_lst.append(f'Taylor Series - {i} terms')
    ax.legend(legend_lst, loc=3)

    plt.show() 

def plot_taylor_seris_3term(angles):
    t_cos = [taylor_seris(angle,3) for angle in angles]
    ax.plot(angles,t_cos)
    ax.set_ylim([-5,5])
    ax.legend(['cos() function','Taylor Series - 3 terms'])

    plt.show()

if __name__ == "__main__":
    angles = np.arange(-2*np.pi,2*np.pi,0.1)
    p_cos = np.cos(angles)

    fig, ax = plt.subplots()
    ax.plot(angles,p_cos)
    plot_taylor_seris_3term(angles)
    #plot_taylor_seris_one_to_five(angles) 

