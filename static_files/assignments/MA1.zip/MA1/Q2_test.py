import Q2
from math import pi,cos

def test_taylor_series():
    assert Q2.taylor_seris(5,3) == 14.541666666666668
    assert Q2.taylor_seris(pi/2,4) == -0.0008945229984747317    
    assert Q2.taylor_seris(0,3) == cos(0)
    assert Q2.taylor_seris(1/2,50) == cos(1/2)
    assert Q2.taylor_seris(1/3,0) == 0

if __name__ == "__main__":
    test_taylor_series()