#include<stdlib.h>

int sub(int a, int b)
{
    return a - b;
}

int add(int a, int b)
{
    return a + b;
}

typedef int (*_ii2i_fp)(int,int);