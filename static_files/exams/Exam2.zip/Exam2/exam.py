class student:
    def __init__(self, id, name):
        self.id = id
        self.name = name



if __name__ == "__main__":
    pass