import math

def q0_distance(x1, y1, x2, y2):
    return math.sqrt((x2-x1)**2+(y2-y1)**2)

def q1_poly1(a, b, x):
    return a*x+b

def q2_poly1_str(a, b):
    return f'{a}x+{b}'

def q3_digit_sum(n):
    s = 0
    while n>0:
        s = s + (n % 10)
        n = int(n / 10)

    return s

def q4_filter_dividable(nums, d):
    nums_result = []
    for n in nums:
        if n % d == 0:
            nums_result.append(n)
    return nums_result

def q5_poly_n(coefs, x):
    s = 0
    xn = 1
    for i in range(len(coefs)):
        s = s + xn * coefs[i]
        xn = xn * x
    
    return s

def q6_poly_n_str(coefs):
    result = ''
    for i in range(len(coefs)):
        if i == 0:
            result = result + f'{coefs[i]}'
        elif i == 1:
            result = result + f'{coefs[i]}x'
        else:            
            result = result + f'{coefs[i]}x^{i}' 

        if i < len(coefs)-1:
            result = result + '+'
    return result 

def q7_poly_n_str2(coefs):
    result = ''
    for n in range(len(coefs)):
        i = len(coefs) - n - 1
        coef = str(coefs[i])
        if coefs[i] == 0:
            continue
        
        if coef == '1' and i > 0:
            coef = ''

        if i == 0:
            result = result + f'{coef}'
        elif i == 1:
            result = result + f'{coef}x'
        else:            
            result = result + f'{coef}x^{i}' 

        if n < len(coefs)-1:
            result = result + '+'
    return result 
